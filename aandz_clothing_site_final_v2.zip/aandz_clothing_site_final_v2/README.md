# A&Z Clothing Brand Website

Benvenuti nel sito ufficiale di **A&Z Clothing**!

## 🎯 Slogan
*From beginning to the end*

## 🎨 Colori principali
- Bianco
- Nero
- Celeste

## 🧥 Collezioni
Il sito mostra i prodotti suddivisi per:
- **Uomo**
  - Magliette
  - Pantaloni
  - Felpe
- **Donna**
  - Magliette
  - Pantaloni
  - Felpe
  - Vestiti
  - Pantaloncini
  - Gonne

## 📩 Contatti
- Email: [azclothing09@gmail.com](mailto:azclothing09@gmail.com)

## 🚀 Come visualizzare il sito
1. Scarica e decomprimi il file ZIP.
2. Apri `index.html` con un browser web.
